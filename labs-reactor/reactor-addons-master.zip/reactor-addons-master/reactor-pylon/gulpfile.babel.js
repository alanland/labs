'use strict';

global.isProd = false;

import './gulp';
